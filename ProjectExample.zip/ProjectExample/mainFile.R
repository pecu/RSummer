mainFile <- function()
{

  table = readAllTable()
  # 判斷內容
  mainFile = 2:100
  
}
