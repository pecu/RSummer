stockIndex <- function()
{

  tabel = readAllTable()
  
  # 判斷買或賣
  get = BuyOrSell(tabel)
  
  stockIndex = 1:10
}
