BuyOrSell <- function(tabel)
{
  # 判斷如何決定買或賣
  BuyOrSell = c(1,0,1,0)
}