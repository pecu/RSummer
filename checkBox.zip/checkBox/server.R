library(shiny)
library(png)

shinyServer(function(input, output, session) {

    selAll <- observeEvent(input$SelectAll, {
      campaigns_list = c("1", "2", "3")
      updateCheckboxGroupInput(session,"checkGroup", selected=campaigns_list)
    })
    
    delALL <- observeEvent(input$DelAll, {
      campaigns_list = c("","","")
      updateCheckboxGroupInput(session,"checkGroup", selected=campaigns_list)
    })
})
