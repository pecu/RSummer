library(shiny)
library(png)

shinyUI(fluidPage(
  
  checkboxGroupInput("checkGroup", 
                     label = h3("Checkbox group"), 
                     choices = list("Choice 1" = 1, 
                                    "Choice 2" = 2, "Choice 3" = 3),
                     selected = 1),
  
  actionButton("SelectAll", label = "SelectAll"),
  actionButton("DelAll", label = "DelAll")

  ))