data = read.csv("Sample.csv")
data = data[order(data$Gender),]

female = data[data$Gender == "female",]
male = data[data$Gender == "male",]

write.csv(female, "female.csv")
write.csv(male, "male.csv")